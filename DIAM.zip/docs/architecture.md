# DIAM Architecture

Describe the system architecture here.