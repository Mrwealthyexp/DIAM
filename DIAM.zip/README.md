# DIAM - Decentralized Identity & Access Management

A Web3-based DApp for secure identity and access management.