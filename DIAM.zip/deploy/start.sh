#!/bin/bash
echo "Starting DIAM"