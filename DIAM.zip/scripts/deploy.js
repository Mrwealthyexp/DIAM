async function main() {
  console.log("Deploying contracts...");
}

main();