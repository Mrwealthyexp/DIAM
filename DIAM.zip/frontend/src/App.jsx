function App() {
  return <div>Welcome to DIAM</div>;
}

export default App;