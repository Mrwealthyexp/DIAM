const { expect } = require("chai");
describe("DIAM", function () {
  it("should deploy correctly", async function () {});
});