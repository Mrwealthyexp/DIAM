module.exports = {
  networks: {},
  compilers: {
    solc: {
      version: '0.8.0'
    }
  }
};